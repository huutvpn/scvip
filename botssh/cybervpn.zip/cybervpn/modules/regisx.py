from cybervpn import *
import subprocess
import datetime as DT

@bot.on(events.CallbackQuery(data=b'regisx'))
async def regisx(event):
    user_id = str(event.sender_id)
    async def regisx_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username:**')
            user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user_msg).raw_text
        
        async with bot.conversation(chat) as pw_conv:
            await event.respond("**Input Ip Vps:**")
            pw_msg = pw_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            pw = (await pw_msg).raw_text
        
        async with bot.conversation(chat) as exp_conv:
            await event.respond("**Choose Expiry Day**", buttons=[
                [Button.inline("• 3 Day •", "3"),
                 Button.inline("• 15 Day •", "15")],
                [Button.inline("• 30 Day •", "30"),
                 Button.inline("• 60 Day •", "60")]
            ])
            exp_msg = exp_conv.wait_event(events.CallbackQuery)
            exp = (await exp_msg).data.decode("ascii")
        
        async with bot.conversation(chat) as ip_conv:
            await event.respond("**Choose ip limit**", buttons=[
                [Button.inline(" 2 IP ", "2"),
                 Button.inline(" 3 IP ", "3")],
                [Button.inline(" 4 IP ", "4"),
                 Button.inline(" 6 IP ", "6")]
            ])
            ip_msg = ip_conv.wait_event(events.CallbackQuery)
            ip = (await ip_msg).data.decode("ascii")
        
        with open(f'/etc/cybervpn/limit/ssh/ip/{user}', 'w') as file:
            file.write(ip)
        
        cmd = f'printf "%s\n" "{pw}" "{user}" "{exp}" | add-ip-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
            subprocess.check_output(cmd, shell=True)
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(exp))
            msg = f"""```{a}```
**» 🤖@YSSHstore**"""
            inline = [
                [Button.url("[ Contact ]", "t.me/YSSHstore"),
                 Button.url("[ Channel ]", "t.me/info_chn1")]
            ]
            await event.respond(msg, buttons=inline)
    
    chat = event.chat_id
    sender = await event.get_sender()
    try:
        level = get_level_from_db(user_id)
        print(f'Retrieved level from database: {level}')

        if level == 'admin':
            await create_ssh_(event)
        else:
            await event.answer(f'Akses Ditolak..!!', alert=True)
    except Exception as e:
        print(f'Error: {e}')

